package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.UltrasonicSensor;


@TeleOp(name = "Drive")
public class ControllerModeV2 extends LinearOpMode {

    // Class for Drive Wheels
    public static class DriveWheels {
        private DcMotor FrontL, FrontR, BackL, BackR;
        private LinearOpMode opMode; // To access gamepad inputs and telemetry from the main op mode
        //private UltrasonicSensor distanceSensor; // Sensor for detecting distance

        // Constants for distance-based speed adjustment
        private final double MIN_POWER = 0.5;
        private final double DEFAULT_POWER = 0.75;
        private final double MAX_POWER = 1.0;

        private final double DECELERATION_START_DISTANCE = 1000; // Placeholder value, need to be experimentally determined
        private final double DECELERATION_END_DISTANCE = 200; // Placeholder value, need to be experimentally determined


        // Tile size (23 inches) divided by inches per encoder step gives the encoder steps per tile
        double encoderStepsPerTileLinear = 2819;

        double encoderStepsPerTileStrafe = 3330;

        double encoderStepsPer90Deg = 2289;
        double autonMotorPower=0.5;
        // Constructor
        public DriveWheels(LinearOpMode opMode) {
            this.opMode = opMode;

            // Motor initialization
            FrontL = opMode.hardwareMap.get(DcMotor.class, "FrontL");
            BackL = opMode.hardwareMap.get(DcMotor.class, "BackL");
            FrontR = opMode.hardwareMap.get(DcMotor.class, "FrontR");
            BackR = opMode.hardwareMap.get(DcMotor.class, "BackR");

            // Set motor directions
            FrontR.setDirection(DcMotorSimple.Direction.REVERSE);
            BackR.setDirection(DcMotorSimple.Direction.REVERSE);

            FrontR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            FrontL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

            FrontR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            FrontL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            BackR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            BackL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        }

        // Method to control the drive based on gamepad input
        public void drive() {
            double leftStickY = -opMode.gamepad1.left_stick_y;
            double leftStickX = opMode.gamepad1.left_stick_x;
            double pivot = opMode.gamepad1.right_stick_x;
            double POWER = DEFAULT_POWER;




             // Default to max speed
             // Adjust back motor speed to match front motors
            //double driveSpeed;
            // Check the distance and adjust speed if necessary
            /*double distance = Double.NaN; // Stores ultrasonic sensor reading
            if (distanceSensor != null) {
                distance = distanceSensor.getUltrasonicLevel(); // Replace with your actual method call.
                if (distance <= DECELERATION_START_DISTANCE) {
                    driveSpeed = calculateDriveSpeed(distance);
                } else {
                    driveSpeed = MAX_SPEED;
                }
            } else {
                driveSpeed = MAX_SPEED; // Default max speed if no sensor is connected.
            }*/

            // Apply triggers for manual speed override
            if (opMode.gamepad1.right_trigger > 0) {
                POWER = MAX_POWER ;
            } else if (opMode.gamepad1.left_trigger > 0) {
                POWER = MIN_POWER ;
            }

            // Set motor powers
            double frontRightPower = constrain(-pivot + (leftStickY - leftStickX), -1.0, 1.0) * POWER;
            double backRightPower = constrain(-pivot + leftStickY + leftStickX, -1.0, 1.0) * POWER;
            double frontLeftPower = constrain(pivot + leftStickY + leftStickX, -1.0, 1.0) * POWER;
            double backLeftPower = constrain(pivot + (leftStickY - leftStickX), -1.0, 1.0) * POWER;

            // Set motor powers
            FrontL.setPower(frontLeftPower);
            FrontR.setPower(frontRightPower);
            BackL.setPower(backLeftPower);
            BackR.setPower(backRightPower);
            // Telemetry for debugging

            opMode.telemetry.addData("FrontL",FrontL.getCurrentPosition());
            opMode.telemetry.addData("FrontR",FrontR.getCurrentPosition());
            opMode.telemetry.addData("BackL",BackL.getCurrentPosition());
            opMode.telemetry.addData("BackR",BackR.getCurrentPosition());

            /*opMode.telemetry.addData("Left Stick Y", leftStickY);
            opMode.telemetry.addData("Left Stick X", leftStickX);
            opMode.telemetry.addData("Pivot", pivot);
//            opMode.telemetry.addData("Drive Speed", driveSpeed);
            if (distanceSensor != null) {
                opMode.telemetry.addData("Ultrasonic Distance", distance);
            }
            // Motor power telemetry
            opMode.telemetry.addData("Front Left Power", FrontL.getPower());
            opMode.telemetry.addData("Front Right Power", FrontR.getPower());
            opMode.telemetry.addData("Back Left Power", BackL.getPower());
            opMode.telemetry.addData("Back Right Power", BackR.getPower());
            //TODO

            opMode.telemetry.addData("DECELERATION_START_DISTANCE", DECELERATION_START_DISTANCE);
            opMode.telemetry.addData("DECELERATION_END_DISTANCE", DECELERATION_END_DISTANCE);
            */
            // Update telemetry with all added data

        }

        // Constraining method
        private double constrain(double var, double min, double max){
            var = Math.min(Math.max(var, min), max);
            return var;
        }

        public void moveLinear(double tiles) {
            int encoderSteps = (int) (tiles*encoderStepsPerTileLinear);
            FrontR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            FrontL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            FrontL.setPower(autonMotorPower);
            FrontR.setPower(autonMotorPower);
            BackL.setPower(autonMotorPower);
            BackR.setPower(autonMotorPower);
            FrontR.setTargetPosition(encoderSteps);
            FrontL.setTargetPosition(encoderSteps);
            BackR.setTargetPosition(encoderSteps);
            BackL.setTargetPosition(encoderSteps);
            FrontR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            FrontL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            BackR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            BackL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        }

        public void strafe(double tiles) {
            int encoderSteps = (int) (tiles*encoderStepsPerTileStrafe);
            FrontR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            FrontL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            FrontL.setPower(autonMotorPower);
            FrontR.setPower(autonMotorPower);
            BackL.setPower(autonMotorPower);
            BackR.setPower(autonMotorPower);
            FrontR.setTargetPosition(-encoderSteps);
            FrontL.setTargetPosition(encoderSteps);
            BackR.setTargetPosition(encoderSteps);
            BackL.setTargetPosition(-encoderSteps);
            FrontR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            FrontL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            BackR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            BackL.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        }

        public void turn90(int direction) {
            int encoderSteps = (int) (direction*encoderStepsPer90Deg);
            FrontR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            FrontL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            BackL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            FrontL.setPower(autonMotorPower);
            FrontR.setPower(autonMotorPower);
            BackL.setPower(autonMotorPower);
            BackR.setPower(autonMotorPower);
            FrontR.setTargetPosition(encoderSteps);
            FrontL.setTargetPosition(-encoderSteps);
            BackR.setTargetPosition(encoderSteps);
            BackL.setTargetPosition(-encoderSteps);
            FrontR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            FrontL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            BackR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            BackL.setMode(DcMotor.RunMode.RUN_TO_POSITION);        }

        public void waitForDrive(){
            while (BackL.isBusy() || BackR.isBusy() || FrontR.isBusy() || FrontL.isBusy()) {
                opMode.telemetry.addData("FrontL",FrontL.getCurrentPosition());
                opMode.telemetry.addData("FrontR",FrontR.getCurrentPosition());
                opMode.telemetry.addData("BackL",BackL.getCurrentPosition());
                opMode.telemetry.addData("BackR",BackR.getCurrentPosition());
                opMode.telemetry.update();
            }

        }
    }
    // Class for the Lift

    public static class Lift {
        private  double liftPower = 1.0;
        private int maxLiftHeight=2000;
        private int minLiftHeight=0;
        private double SPEED;
        private DcMotor LiftL, LiftR;
        private Plate plate; // Reference to Plate object
        private LinearOpMode opMode;
        private double liftHeight = 0;
        private double plateLiftSafety = 0;
        public Lift(LinearOpMode opMode, Plate plate) {
            this.opMode = opMode;
            this.plate = plate;
            this.LiftL = this.opMode.hardwareMap.get(DcMotor.class, "LiftL");
            this.LiftR = this.opMode.hardwareMap.get(DcMotor.class, "LiftR");

            LiftL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            LiftR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);


        }

        public double constrain(double var, double min, double max){
            var = Math.min(Math.max(var, min), max);
            return var;
        }

        public void controlLift() {
            // Use the left stick y-axis to control the lift motors
            LiftL.setPower(liftPower);
            LiftR.setPower(-liftPower);

            if (opMode.gamepad2.left_trigger > 0) {
                liftPower = 1.0;
                SPEED = 50 ;
            } else  {
                liftPower = 1.0;
                SPEED = 80 ;
            }
            if (opMode.gamepad2.left_stick_y == 1 && LiftL.getCurrentPosition() <= liftHeight + SPEED  ) {
                liftHeight = liftHeight - SPEED;
            }
            if (opMode.gamepad2.left_stick_y == -1 && LiftL.getCurrentPosition() >= liftHeight - SPEED ) {
                liftHeight = liftHeight + SPEED;
            }
            liftHeight = constrain(liftHeight, minLiftHeight, maxLiftHeight);

            LiftL.setTargetPosition((int) liftHeight);
            LiftR.setTargetPosition((int) -liftHeight);
            LiftR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            LiftL.setMode(DcMotor.RunMode.RUN_TO_POSITION);

            if (opMode.gamepad2.right_bumper){
                liftHeight = maxLiftHeight;
            }



            if (getLiftPosition() > plateLiftSafety) {
                plate.adjustPlate();
            }
            // Add telemetry data if needed to observe motor powers
            opMode.telemetry.addData("Lift Power", liftPower);
            opMode.telemetry.addData("Lift Height", liftHeight);

            opMode.telemetry.addData("LiftL Position", LiftL.getCurrentPosition());
           opMode.telemetry.addData("LiftR Position", LiftR.getCurrentPosition());
            plate.getPos();
        }
        /*
        public void controlLift() {
            // First check if the plate is moving and set power to the motors accordingly
            if (plateMoving) {
                if (plate.isPlateAtTarget()) { // Assuming this method checks if plate is either in the initial or horizontal position as needed.
                    plateMoving = false; // Stop motion if the plate reached its position.
                }
            } else {

                // If plate is not moving, control the motors based on gamepad input.
                double liftPower = opMode.gamepad2.left_stick_y;
                adjustmentPower = liftPower; // Set the input power to adjustmentPower, this will be the base motor power unless overridden by manual controls.
                telemetry.addData("lift Power", liftPower);
                if (opMode.gamepad2.dpad_up) {
                    adjustmentPower = 0.2; // Override with slow speed for fine adjustments.
                } else if (opMode.gamepad2.dpad_down) {
                    adjustmentPower = -0.2; // Override with slow speed for fine adjustments.
                }

                // Check for safety limits and change the adjustment power to 0 if necessary.
                boolean atUpperLimit = adjustmentPower > 0 && getLiftPosition() >= maxLiftHeight;
                boolean atLowerLimit = adjustmentPower < 0 && getLiftPosition() <= minLiftHeight;
                if (atUpperLimit || atLowerLimit) {
                    adjustmentPower = 0; // Stop the motors if we are at the limits.
                }

                // Move the plate if necessary based on lift position and requested motion
                if (getLiftPosition() <= minLiftHeight && liftPower > 0) { // Moving up from base position to any higher.
                    plate.startMovingToHorizontal();
                    plateMoving = true; // Flag that we have initiated a move to horizontal.
                    adjustmentPower = 0; // Do not move lift until the plate has reached horizontal.
                    telemetry.addData("AAAAAAA", "AAAA2");
                } else if (getLiftPosition() > minLiftHeight && liftPower < 0 && !plate.isPlateHorizontal()) { // Moving down towards base from a higher position.
                    plate.moveToInitPosition();
                    plateMoving = true; // Flag that we have initiated a move to the initial position.
                    adjustmentPower = 0; // Do not move lift until the plate has reached the initial position.
                    telemetry.addData("AAAAAAA", "AAAA1");
                }

                // Now we set the motor power based on the computed adjustmentPower value.
                LiftL.setPower(adjustmentPower);
                LiftR.setPower(-adjustmentPower);
            }

            // Telemetry to send feedback
            plate.getPos();
            telemetry.addData("LiftL Position", LiftL.getCurrentPosition());
            telemetry.addData("LiftR Position", LiftR.getCurrentPosition());
            telemetry.update();
        }

         */
//TODO
//        public void setSensor() {
//            this.distanceSensor = distanceSensor;
//       }
        public void useDistanceSensor() {
            //double distance = this.distanceSensor.getUltrasonicLevel();
            // Logic for slowing down the lift based on distance
            // NEEDS TO BE IMPLEMENTED
        }
        private void overrideForSafety() {
            // Logic to override any move functions to ensure safety, using distance sensors
            // NEEDS TO BE IMPLEMENTED
        }

        public int getLiftPosition() {
            // Return the average of the encoder values if both motors move equally.
            // If they do not move equally consider how you'd want to handle this.
            return LiftL.getCurrentPosition();

        }
        public void waitForLift(){
            while (LiftL.isBusy() || LiftR.isBusy()){}
        }
        public void raiseLift(){
            LiftL.setTargetPosition( maxLiftHeight);
            LiftR.setTargetPosition( maxLiftHeight);
            LiftL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            LiftR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        }
        public void lowerLift(){
            LiftL.setTargetPosition( minLiftHeight);
            LiftR.setTargetPosition( minLiftHeight);
            LiftL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            LiftR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        }

        }

    public static class Plate {
        private Servo PlateL, PlateR;
        private LinearOpMode opMode;

        private final double initAngle = 0.0; // Position for 35 degrees. Needs to be set experimentally
        private final double backDropAngle = 0.1; // Position for 0 degrees. Set this experimentally

        // Additional state tracking, based on the lift's position
        private boolean isMovingToHorizontal = false;
        // Thresholds for determining 'at position' states
        private final double POSITION_THRESHOLD = 0.05; // This is an example value that needs to be tuned empirically
        private boolean toggle = true;
        private boolean buttonPressed = false;
        // Booleans to track the state of the plate's movement

        // Constructor

        // Constructor
        public Plate(LinearOpMode opMode) {
            this.opMode = opMode;

            // Initialize servos
            PlateL = opMode.hardwareMap.get(Servo.class, "PlateL");
            PlateR = opMode.hardwareMap.get(Servo.class, "PlateR");
            moveToInit();
        }
        // Call this method when you want to start moving the plate to the horizontal position
        public void moveToBackDrop() {
            PlateL.setPosition(backDropAngle);
            PlateR.setPosition(1-backDropAngle);
        }

        public void moveToInit(){
            PlateL.setPosition(initAngle);
            PlateR.setPosition(1-initAngle);
        }




        public void adjustPlate() {
            // Check if we've reached the desired position to update the movingToHorizontal flag

            if (opMode.gamepad2.a && !buttonPressed) {
                toggle = !toggle ;// Toggle the state only when the button is newly pressed
                buttonPressed = true;
            } else if (!opMode.gamepad2.x && buttonPressed) {
                buttonPressed = false; // Reset the flag when the button is released
            }
            if (toggle){
                moveToInit();
            } else {
                moveToBackDrop();
            }
            // No need for else block, as any real-time control should probably be initiated elsewhere
        }

        // Manual adjustment of the Plate servos
        public void adjustServosManually() {

                double PlateLPosition = PlateL.getPosition();
                double PlateRPosition = PlateR.getPosition();

                if (opMode.gamepad2.dpad_right) {
                    PlateLPosition += 0.01; // Increment for adjustment
                    PlateRPosition += 0.01; // Increment for adjustment
                } else if (opMode.gamepad2.dpad_left) {
                    PlateLPosition -= 0.01; // Decrement for adjustment
                    PlateRPosition -= 0.01; // Decrement for adjustment
                }
                opMode.sleep(100);

                // Constrain servo positions between 0.0 and 1.0
                PlateLPosition = Math.max(0.0, Math.min(1.0, PlateLPosition));
                PlateRPosition = Math.max(0.0, Math.min(1.0, PlateRPosition));

                // Update servo positions
                PlateL.setPosition(PlateLPosition);
                PlateR.setPosition(PlateRPosition);

                // Telemetry to show current servo positions
                opMode.telemetry.addData("PlateL Position", PlateLPosition);
                opMode.telemetry.addData("PlateR Position", PlateRPosition);
                opMode.telemetry.update();

                // Small delay to allow for distinct telemetry readings and adjustments

        }
        // Additional logic to call when plate movement has concluded
        public void getPos(){
            double PlateLPosition = PlateL.getPosition();
            double PlateRPosition = PlateR.getPosition();
            opMode.telemetry.addData("PlateL Position", PlateLPosition);
            opMode.telemetry.addData("PlateR Position", PlateRPosition);
        }

    }

    // Class for the Gate

    public static class Gate {
        private final LinearOpMode opMode;
        private Servo gateServo;
        private boolean gateToggle = false;
        private boolean gateButtonPressed = false;

        private double close = 0.05;
        private double open = 0;

        public Gate(LinearOpMode opMode) {
            // Initialize servo
            this.opMode = opMode;
            gateServo = opMode.hardwareMap.get(Servo.class, "GateServo");
            openGate();
        }


        public void controlGate() {
            if (opMode.gamepad2.b && !gateButtonPressed) {
                gateToggle = !gateToggle; // Toggle the state
                gateButtonPressed = true;
            } else if (!opMode.gamepad2.b) {
                gateButtonPressed = false; // Button has been released, can be pressed again.
            }
            if (gateToggle) {
                closeGate();
                opMode.telemetry.addLine("Gate Closed");
            }else{
                openGate();
                opMode.telemetry.addLine("Gate Open");
            }
        }
        public void openGate(){
            gateServo.setPosition(open);
        }
        public void closeGate(){
            gateServo.setPosition(close);
        }
    }

    public static class LinearGeckoWheels {
        private DcMotor geckoMotor;
        private LinearOpMode opMode; // To access gamepad inputs and telemetry from the main op mode
        private boolean isRunning = true; // Default is running
        private boolean buttonPressed = false; // To track the current state of the button press
        private boolean toggle = true;
        // Constructor
        public LinearGeckoWheels(LinearOpMode opMode) {
            this.opMode = opMode;

            // Initialize motor
            geckoMotor = opMode.hardwareMap.get(DcMotor.class, "GeckoMotor");
        }


        // Method to update the state of the gecko wheels based on gamepad input
        public void updateGeckoWheels() {
            // This is a state-change detection - when the button is pressed, but was not pressed before
            if (opMode.gamepad2.x && !buttonPressed) {
                toggle = !toggle ;// Toggle the state only when the button is newly pressed
                buttonPressed = true;
            } else if (!opMode.gamepad2.x && buttonPressed) {
                buttonPressed = false; // Reset the flag when the button is released
            }
            if (toggle){
                geckoMotor.setPower(1.0);

            } else {
                ejectPixel(true);
            }
        }

        public void ejectPixel(boolean Fast) {
            if (Fast){
                geckoMotor.setPower(-1.0);
            } else {
                geckoMotor.setPower(-0.5);
            }
        }

    }

    // Class for the Plane Launcher
    public static class PlaneLauncher {
        private final LinearOpMode opMode;
        private Servo launcherServo;
        private boolean planeToggle = false;
        private boolean planeButtonPressed = false;

        public PlaneLauncher(LinearOpMode opMode) {
            // Initialize servo
            this.opMode = opMode;
            launcherServo = opMode.hardwareMap.get(Servo.class, "LauncherServo");
            launcherServo.setPosition(0);
        }

        /**
         * Toggles the plane launcher servo 90 degrees back and forth with the A button on gamepad 2.
         */
        public void controlLauncher() {
            if (opMode.gamepad2.y && !planeButtonPressed) {
                planeToggle = !planeToggle; // Toggle the state
                planeButtonPressed = true;
            } else if (!opMode.gamepad2.y) {
                planeButtonPressed = false; // Button has been released, can be pressed again.
            }
            if (planeToggle) {
                launcherServo.setPosition(0.7);
                opMode.telemetry.addLine("Plane Launched");
            }else{
                launcherServo.setPosition(0);
                opMode.telemetry.addLine(" Plane Docked");
            }
        }
    }
/*
    public static class ColSensor{
        private ColorSensor colorSensor;
        private LinearOpMode opMode; // To allow for telemetry and .sleep()

        private double redValue;
        private double greenValue;
        private double blueValue;
        private double alphaValue;
        private double targetValue;
        private float[] targetColorHsv = new float[3]; // HSV values for the target color

        public ColSensor(LinearOpMode opMode) {
            this.opMode = opMode;
            // Initialize the color sensor
            this.colorSensor = opMode.hardwareMap.get(ColorSensor.class, "color");
        }
        // Method to calibrate the sensor by detecting target color once and storing the HSV values
        public void getColor(){
            redValue = colorSensor.red();
            greenValue = colorSensor.green();
            blueValue = colorSensor.blue();
            alphaValue = colorSensor.alpha();
        }
        public void calibrateSensor() {
            // Fetch the RGB values of the detected color
            float[] hsvValues = new float[3];
            Color.RGBToHSV(
                    colorSensor.red() * 8,   // Multiplying to scale up, as RGBToHSV expects values between 0-255
                    colorSensor.green() * 8,
                    colorSensor.blue() * 8,
                    hsvValues
            );

            // Store these as the target color
            targetColorHsv = hsvValues;

            // Telemetry for calibration debugging
            opMode.telemetry.addData("Calibrated HSV", "H: %.2f, S: %.2f, V: %.2f", hsvValues[0], hsvValues[1], hsvValues[2]);
            opMode.telemetry.update();
        }
    }

    public class ColSensor {
        private ColorSensor colorSensor;
        private LinearOpMode opMode; // To allow for telemetry and .sleep()
        private DcMotor motor; // The motor you want to control based on the color sensor

        private float[] targetColorHsv = new float[3]; // HSV values for the target color

        // Constructor
        public ColSensor(LinearOpMode opMode, DcMotor motor, String sensorName) {
            this.opMode = opMode;
            this.motor = motor;

            // Initialize the color sensor
            this.colorSensor = opMode.hardwareMap.get(ColorSensor.class, sensorName);
        }

        // Method to calibrate the sensor by detecting target color once and storing the HSV values
        public void calibrateSensor() {
            // Fetch the RGB values of the detected color
            float[] hsvValues = new float[3];
            Color.RGBToHSV(
                    colorSensor.red() * 8,   // Multiplying to scale up, as RGBToHSV expects values between 0-255
                    colorSensor.green() * 8,
                    colorSensor.blue() * 8,
                    hsvValues
            );

            // Store these as the target color
            targetColorHsv = hsvValues;

            // Telemetry for calibration debugging
            opMode.telemetry.addData("Calibrated HSV", "H: %.2f, S: %.2f, V: %.2f", hsvValues[0], hsvValues[1], hsvValues[2]);
            opMode.telemetry.update();
        }

        // Method that waits for the color sensor to read the target color,
        // stops the motor and resets the encoder once seen.
        public void waitForColor() {
            float[] hsvValues = new float[3];

            // Keep checking the color sensor readings
            while(opMode.opModeIsActive()) {
                // Convert the current RGB values to HSV and store in hsvValues
                Color.RGBToHSV(
                        colorSensor.red() * 8,
                        colorSensor.green() * 8,
                        colorSensor.blue() * 8,
                        hsvValues
                );

                // Check if the detected color is close to the target color
                if (isTargetColor(hsvValues, targetColorHsv)) {
                    // Desired color has been seen so stop and reset motor

                    break; // Break out of the loop
                }

                opMode.sleep(50); // Small delay for responsiveness
            }
        }

        // Helper method to determine if the detected color is close to the target color
        private boolean isTargetColor(float[] detectedHsv, float[] targetHsv) {
            final float COLOR_THRESHOLD = 10.0f; // HSV threshold for color detection

            // Simple threshold check for all 3 HSV components
            return Math.abs(detectedHsv[0] - targetHsv[0]) < COLOR_THRESHOLD &&
                    Math.abs(detectedHsv[1] - targetHsv[1]) < COLOR_THRESHOLD &&
                    Math.abs(detectedHsv[2] - targetHsv[2]) < COLOR_THRESHOLD;
        }
    }
*/
    // Instances of components
    private DriveWheels driveWheels;
    private Lift lift;
    private Plate plate;
    private Gate gate;
    private LinearGeckoWheels geckoWheels;
    private PlaneLauncher planeLauncher;


    @Override
        public void runOpMode() {
            // Hardware initialization

                    //hardwareMap.get(UltrasonicSensor.class, "distanceSensor");

            // Initialize the components using the class instance variables
            driveWheels = new DriveWheels(this);
            plate = new Plate(this);
            lift = new Lift(this, plate);
            gate = new Gate(this);
            planeLauncher = new PlaneLauncher(this);
            geckoWheels = new LinearGeckoWheels(this); // Make sure geckoWheels is a class instance variable

            // Wait for the game to start (driver presses PLAY)
            waitForStart();

            while (opModeIsActive()) {
                // Update the state of the drive wheels
                driveWheels.drive();
                // Update the state of the lift
                lift.controlLift();//Uses Gamepad 2 a for plate, LeftstickY for lift, and Triggers for lift Speed
                gate.controlGate(); // Uses Gampad 2 b
                plate.adjustServosManually();
                geckoWheels.updateGeckoWheels();//Use Gamepad 2 x
                planeLauncher.controlLauncher();//Use Gamepad 2 y

                // Telemetry update. You can add more telemetry outputs as needed for debugging.
//                telemetry.addData("Lift Position", lift.getLiftPosition()); // Assuming getLiftPosition exists and returns some value
//                telemetry.addData("Plate Horizontal", plate.isPlateHorizontal()); // Assuming isPlateHorizontal method exists
                telemetry.update();
            }
        }
    }